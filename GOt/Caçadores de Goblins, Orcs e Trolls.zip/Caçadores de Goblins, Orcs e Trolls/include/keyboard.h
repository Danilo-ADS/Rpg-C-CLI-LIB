#ifndef KEYBOARD_H
#define KEYBOARD_H

char obter_acao_jogador();

int escolher_melhoria();

#endif
