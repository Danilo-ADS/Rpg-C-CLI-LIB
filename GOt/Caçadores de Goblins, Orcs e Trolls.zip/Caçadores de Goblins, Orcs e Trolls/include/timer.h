#ifndef TIMER_H
#define TIMER_H

void iniciar_temporizador();

double parar_temporizador();

double obter_tempo_decorrido();

#endif
